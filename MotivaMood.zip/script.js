
const frases = {
  general: [
    "Tú puedes con esto y con más.",
    "No te rindas, lo mejor está por venir.",
    "Respira hondo y sigue.",
    "Eres más fuerte de lo que piensas."
  ],
  gym: [
    "Una repetición más te acerca a tu meta.",
    "El dolor de hoy es la fuerza de mañana.",
    "No pares hasta estar orgulloso."
  ],
  tristeza: [
    "Llorar también es parte de sanar.",
    "Después de la tormenta, siempre sale el sol.",
    "No estás solo, aunque a veces lo parezca."
  ],
  alegria: [
    "Disfruta el momento, estás vivo.",
    "Sonríe, el mundo es mejor con tu risa.",
    "La alegría también se entrena."
  ],
  depresion: [
    "Está bien pedir ayuda, no estás solo.",
    "Un paso a la vez, con calma.",
    "Hoy puede ser difícil, pero no eterno."
  ],
  amor_propio: [
    "Quiérete como quieres que te quieran.",
    "Tu valor no depende de nadie más.",
    "Eres suficiente, tal y como eres."
  ],
  no_me_rindo: [
    "Aunque sea lento, avanza.",
    "No te detengas ahora, ya llegaste lejos.",
    "Cada intento cuenta, cada paso suma."
  ]
};

function nuevaFrase() {
  const lista = frases.general;
  const random = Math.floor(Math.random() * lista.length);
  document.getElementById("frase").innerText = lista[random];
}

function mostrarCategoria(cat) {
  const lista = frases[cat] || [];
  const random = Math.floor(Math.random() * lista.length);
  document.getElementById("frase").innerText = lista[random];
}

function buscarFrase() {
  const query = document.getElementById("buscador").value.toLowerCase();
  let resultado = "";
  for (const cat in frases) {
    frases[cat].forEach(f => {
      if (f.toLowerCase().includes(query)) {
        resultado = f;
      }
    });
  }
  document.getElementById("frase").innerText = resultado || "No encontramos una frase, intenta otra palabra.";
}
