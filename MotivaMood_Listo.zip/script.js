document.getElementById('buscador').addEventListener('input', function(e) {
  const query = e.target.value.toLowerCase();
  const secciones = document.querySelectorAll('main section');
  secciones.forEach(section => {
    const text = section.innerText.toLowerCase();
    section.style.display = text.includes(query) ? 'block' : 'none';
  });
});
